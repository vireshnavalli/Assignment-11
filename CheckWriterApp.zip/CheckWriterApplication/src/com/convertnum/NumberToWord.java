package com.convertnum;

class NumberToWord  {
	 private static final String[] specialNames = {
		 ""," thousand"," million"," billion"," trillion"," quadrillion"," quintillion"
	 };

	 private static final String[] tensNames = {
		 ""," ten"," twenty"," thirty"," forty"," fifty"," sixty"," seventy"," eighty"," ninety"
	 };

	 private static final String[] numNames = {
		 ""," one"," two"," three"," four", " five", " six"," seven"," eight"," nine"," ten"," eleven"," twelve"," thirteen"," fourteen", " fifteen"," sixteen"," seventeen", " eighteen"," nineteen"
	 };

	 private String convertLessThanOneThousand(int number) {
		 String current;

		 if (number % 100 < 20){
			 current = numNames[number % 100];
			 number /= 100;
		 }
		 else {
			 current = numNames[number % 10];
			 number /= 10;

			 current = tensNames[number % 10] + current;
			 number /= 10;
		 }
		 if (number == 0) return current;
		 return numNames[number] + " hundred" + current;
	 }

	 public String convert(double number) {
		 String result="";  
		 if (number == 0 || number < 0) { return "Error:Enter a number > zero"; }

		 int x = (int)number;

		 if(x != number){

			 String numberStr = Double.toString(number);
			 String fractionalStr[] = numberStr.split("\\.");
			 int integerPart = Integer.valueOf(fractionalStr[0]);
			 int fractionalPart = Integer.valueOf(fractionalStr[1]);

			 String strnum = Integer.toString(fractionalPart);
			 StringBuffer sb = new StringBuffer(" dollars and ").append(strnum).append("/1");
			 char ch[] = strnum.toCharArray();

			 for(int i=1;i<=ch.length;i++){
				 sb.append(0);			 
			 }

			 result = callerMethod(integerPart).concat(sb.toString());
		 }
		 else
			 result = callerMethod(x).concat(" dollars only");

		 return (result.substring(0, 1).toUpperCase() + result.substring(1));	
	 }     


	 public String callerMethod(int number){
		 String current = "";
		 int place = 0;

		 do {
			 int n = number % 1000;
			 if (n != 0){
				 String s = convertLessThanOneThousand(n);
				 current = s + specialNames[place] + current;
			 }
			 place++;
			 number /= 1000;
		 } while (number > 0);

		 return (current).trim();
	 }
	 
	 //For Stand-alone Application Reomve below Comments
	 /*public static void main(String[] args) {
		 NumberToWord obj = new NumberToWord();
		 System.out.println(obj.convert(125.75));
		 System.out.println(obj.convert(95.00));
		 System.out.println(obj.convert(69));

	 }*/
}