package com.convertnum;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class OnServletCall extends HttpServlet  
{
	protected void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");

		String inputStr=req.getParameter("number");
		System.out.println(inputStr);
		NumberToWord numtotext = new NumberToWord();

		String result = numtotext.convert(Double.parseDouble(inputStr));
		pw.print("<font face='verdana'>");
		pw.println("The English equivalent for given Currency:::");
		pw.println(result);
		pw.print("</font>");
		pw.close();
	}
}

