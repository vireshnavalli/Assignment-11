package com.convertnum;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class NumberToWordsTest {


	private NumberToWord numtoword;

	@Before
	public void setUp() {
		numtoword = new NumberToWord();
	}
	
	public void invalidInput() {
        String message = numtoword.convert(0);
        assertEquals("Error:Enter a number > zero", message);
    }
	
	public void invalidInput2() {
        String message = numtoword.convert(-123);
        assertEquals("Error:Enter a number > zero", message);
    }


	@Test
	public void test() {
		assertEqual(1500000, "One million five hundred thousand dollars only");
		assertEqual(125.75, "One hundred twenty five dollars and 75/100");
		assertEqual(95.00, "Ninety five dollars only");
		assertEqual(69, "Sixty nine dollars only");
	}

	private void assertEqual(double num, String expected) {
		String result = numtoword.convert(num);
		assertEquals(expected,result);
	}


}